/**
 * WHY THIS WAS REWRITTEN
 *
 * The original prompt said, in the same breath: "do not invent containers",
 * "do not invent classes", and "produce clean, properly indented HTML" -
 * but a real layout (a centered max-width content area, a flex/grid wrapper
 * around a nav, a card grid wrapper) almost always needs structural wrapper
 * elements that an architecture spec at the section/component level will
 * never enumerate one-for-one. The old prompt gave the model no legal way
 * to write normal HTML without "inventing" something, which likely pushed
 * it toward either (a) flat, unstyleable markup with no wrappers, or
 * (b) ignoring the rule outright and adding structure inconsistent with
 * what the CSS/JS prompts (which got the *same* "don't invent" instruction
 * against the *same* spec) assumed. This version draws the line explicitly:
 * the IDs/classes/content in the architecture are fixed; purely structural
 * wrapper elements needed to lay them out are allowed and expected.
 */
import { loadSkill } from "../skills/loader";
import { Architecture } from "../types/architecture";
import { Blueprint } from "../types/blueprint";

function htmlGuidance(): string {
  return loadSkill("html-semantics");
}

export const htmlPrompt = (userPrompt: string, architecture: Architecture, blueprint: Blueprint) => `
You are a senior frontend engineer writing semantic, accessible HTML.

The architecture below is the single source of truth for:
- what exists on the page
- what each section/component is for
- the intended emphasis and layout of each section

You may add neutral structural wrappers when needed for layout, but you may NOT invent new sections, rename ids/classes, or contradict the architecture.

Markup guidance:
${htmlGuidance()}

Rules:
1. Return ONLY the raw HTML document - no markdown fences, no comments, no explanation.
2. Produce one complete HTML5 document with:
   - <!DOCTYPE html>
   - <html lang="en">
   - <head> with charset, viewport, title from seo.metaTitle or project.title, meta description, stylesheet link to "./style.css"
   - <body>
3. Include semantic structure: header, main, footer where appropriate.
4. Render every section in pages[0].sections in order, using the exact tag, id, and className provided.
5. Render every component using the exact id/className/tag provided, nested where its purpose and belongsToSection imply.
6. You may add neutral wrappers such as .container, .stack, .cluster, .grid only if they do not replace required ids/classes and are clearly structural.
7. Treat "layout", "variant", "purpose", and "emphasis" as implementation instructions for nesting and structure.
8. Use proper accessibility attributes: alt text, labels, aria-label, landmark semantics, button type, list semantics, heading hierarchy.
9. Ensure every interaction selector in architecture.interactions exists in the HTML exactly.
10. Do not inline CSS or JavaScript.
11. End with <script src="./script.js"></script> before </body>.
12. The result must be suitable for a production-looking single-page site, not a wireframe.

User request:
${userPrompt}

Architecture:
${JSON.stringify(architecture, null, 2)}

Blueprint (final decisions - render sections in exactly this order, use theme colors/fonts as the CSS custom property values, use hero.headline/subheading/cta as the hero copy, and mark whichever section corresponds to featuredProject/featuredExperience as the emphasized one):
${JSON.stringify(blueprint, null, 2)}
`;
