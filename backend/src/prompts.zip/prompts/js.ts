 
import { Architecture } from "../types/architecture";
import { Blueprint } from "../types/blueprint";
import { loadSkill } from "../skills/loader";

function jsGuidance(): string {
  const interactivity = loadSkill("js-interactivity");
  const guardrails = `
Write plain, maintainable vanilla JavaScript.
Prefer small named functions over one large script.
Use event delegation when multiple matching elements may exist.
Never assume a selector exists - guard every query before use.
Do not add visual design decisions in JavaScript unless an interaction explicitly requires class toggling or state updates.
Keep behavior progressively enhanced: if JavaScript fails, the page should remain structurally usable.
`;
  return `${interactivity}\n\n${guardrails}`;
}

export const jsPrompt = (
  userPrompt: string,
  architecture: Architecture,
  blueprint: Blueprint,
  html: string
) => `
You are a senior JavaScript engineer writing production-quality vanilla JavaScript for the exact HTML document below.

Your only job is to implement the interactions defined in the architecture.
Do not invent extra functionality.
Do not redesign the page in JavaScript.

Scripting guidance:
${jsGuidance()}

Interactions to implement:
${JSON.stringify(architecture.interactions, null, 2)}

Implementation notes:
${JSON.stringify(architecture.implementationNotes, null, 2)}

Relevant design directives:
${JSON.stringify(
  {
    motionStyle: architecture.designDirectives.motionStyle,
    mustAvoid: architecture.designDirectives.mustAvoid,
    antiPatterns: architecture.designDirectives.antiPatterns,
  },
  null,
  2
)}

Rules:
1. Return ONLY raw JavaScript - no markdown fences, no explanation, no surrounding text.
2. Wrap all setup in a single DOMContentLoaded listener.
3. Only query selectors that actually exist in the HTML below. Guard every query before using it.
4. Implement only the interactions listed in architecture.interactions. If the array is empty, return a minimal valid script with no behavior.
5. Use const/let, addEventListener, querySelector/querySelectorAll, closest, classList, dataset, and small helper functions where useful.
6. Prefer event delegation for repeated or list-like UI.
7. Do not modify the HTML structure unless an interaction explicitly requires creating/removing an element.
8. Do not inject inline styles. Prefer toggling existing classes, ARIA attributes, data attributes, disabled states, hidden states, or text content when needed.
9. If an interaction implies UI state, keep that state minimal and local.
10. Do not use frameworks, TypeScript syntax, modules, imports, jQuery, or external libraries.
11. Do not use localStorage, sessionStorage, IndexedDB, or cookies unless the user explicitly requested persistence.
12. Do not use alert(), confirm(), or prompt() unless the interaction explicitly requires a browser dialog. Browser prompt dialogs should be used sparingly because they block interaction with the rest of the page. [web:53][web:52]
13. For forms:
    - prevent default only when the described behavior requires client-side handling
    - validate only what the interaction explicitly implies
    - update accessible states when relevant (aria-expanded, aria-hidden, disabled, hidden)
14. For toggles, accordions, tabs, menus, and disclosures:
    - keep keyboard-safe behavior where relevant
    - keep state synchronized via classes and ARIA attributes
15. Code must fail gracefully. Missing elements must never throw runtime errors.
16. Keep the file concise. No dead code, no placeholder TODOs, no speculative utilities.

Behavior mapping requirements:
- Treat each interaction object as authoritative.
- "selector" will point to an id or class that must already exist in the HTML.
- "event" tells you which listener to attach.
- "behavior" tells you what to implement in plain language.
- "target", if present, indicates the secondary element affected by the interaction.
- "progressiveEnhancement" indicates the behavior should preserve a usable non-JS fallback.

Implementation style requirements:
- Start with document.addEventListener("DOMContentLoaded", () => { ... });
- Inside, create small helper functions only if they are reused or improve clarity.
- If multiple interactions share logic, extract a helper.
- Use semantic state updates where possible:
  - toggle aria-expanded for expandable controls
  - toggle hidden or aria-hidden for revealed panels
  - toggle disabled for temporary disabled states
  - update textContent only when behavior explicitly implies it
- If a submit interaction only needs a lightweight demo behavior, do not fabricate network requests unless the user request explicitly asked for them.

If architecture.interactions is empty, return exactly this:
document.addEventListener("DOMContentLoaded", () => {});

User request:
${userPrompt}

Architecture:
${JSON.stringify(architecture, null, 2)}

Blueprint (for context only - featuredProject/featuredExperience may inform which element an interaction like "scroll to" or "highlight" should target):
${JSON.stringify(blueprint, null, 2)}

HTML the script will run against:
${html}
`;
